import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="goFindThem-pkg-carbonUnit42", # Replace with your own username
    version="0.0.1",
    author="Micah Hoffman, Bryan Galbraith",
    author_email=" ",
    description="Search for Usernames on a variety of websites",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/WebBreacher/WhatsMyName",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)